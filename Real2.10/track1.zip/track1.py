"""
Tracking a car through a live video feed

The car carries two coloured markers: a green one at the centre (position)
and a blue one at the front (heading = direction green -> blue), so the
heading is known even when the car is stopped.

Input: Live video feed through a USB camera

Output: Video with the car's current location, as well as the lap number, lap time and best lap time overall

Lap info is displayed in a bottom border

"""
import atexit
import cv2
import numpy as np
import os
import time
import json
import socket
import re
from pathlib import Path
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shared_config import (
    BARRIER_INNER_EXTRA_M,
    BARRIER_INNER_M,
    BARRIER_OUTER_M,
    BARRIER_ROUND_CORNER_RADIUS_M,
    BARRIER_ROUND_CORNER_SAMPLES,
    BLUE_HSV_LOWER,
    BLUE_HSV_UPPER,
    CONTROLLER_PARAMS,
    GREEN_HSV_LOWER,
    GREEN_HSV_UPPER,
    MARKER_THETA_OFFSET_DEG,
    OBSTACLES_M,
    ROBOT_ELLIPSE_A_M,
    ROBOT_ELLIPSE_B_M,
    TRACK_POINTS_M,
)
from undistort import undistort_frame

try:
    from controller import build_spline_path  # mesmo caminho (spline) que o runner segue
except Exception as _e:  # sem scipy: o log fica sem a spline
    build_spline_path = None
    print(f"Warning: sem controller.build_spline_path ({_e}); o log do video nao tera a spline.")

#Global Variables
kernel = np.ones((3,3),np.uint8)
contour = None
lap_number = 0 
lap_start_time = 0 
lap_time = 1001
batota = 0
best_lap_time = 1000
#Aux variables
aux = 0 #flag for passing the goal
f_red = 0 #flag for going out of bounds
red = None
click_count = 0
edit_drag_target = None
edited_points_dirty = False

POINT_PICK_RADIUS_PX = 14
SHARED_CONFIG_PATH = Path(__file__).with_name("shared_config.py")

# Crop constants
frame_height = 0
frame_width = 0
raw_frame_height = 0
raw_frame_width = 0
CROP_HEIGHT_FACTOR = 8
CROP_WIDTH_START = None
CROP_WIDTH_END = None
CROP_HEIGHT_START = None
CROP_HEIGHT_END = None
SELECT_CROP_AT_START = True  # escolher o corte com o rato ao arrancar
CAMERA_INDEX = 0  # webcam USB (iCatch V37); a do PC e o 1. A ordem pode mudar!
CAMERA_WIDTH, CAMERA_HEIGHT = 1280, 720  # igual ao cam.py e ao calibrate_camera.py
RESIZE_FACTOR = 0.9
INVERT_IMAGE = True
INVERT_FLIP_CODE = -1  # 1=horizontal, 0=vertical, -1=ambas
static_overlay_version = 0  # incrementa ao editar pontos/obstaculos -> redesenha a pista
_static_overlay_cache = {"key": None, "data": None}
ROUND_CORNER_RADIUS_M = 0.2
ROUND_CORNER_SAMPLES = 24
RAW_SPEED_UPDATE_CYCLES = 1
RAW_THETA_MIN_UPDATE_M = 0.03

raw_theta_rad = 3.14
raw_speed_m_s = 0.0
raw_speed_anchor_pos_m = None
raw_speed_anchor_t = None
raw_speed_cycle_count = 0
raw_theta_anchor_pos_m = None
raw_x_m = None
raw_y_m = None

# Referencial em metros (mesmo do cam2.py, antes das transformacoes do frame)
REF_PX_ORIGIN_RAW = (616.0, 600.0)
REF_PX_X_AXIS_RAW = (892.0, 600.0)
REF_X_METERS = 0.9
REF_PX_ORIGIN = None
REF_PX_X_AXIS = None
PIXEL_TO_METER = None

#Finishing line coordinates
FINISHING_LINE_MIN_X = None
FINISHING_LINE_MAX_X = None
FINISHING_LINE_MIN_Y = None
FINISHING_LINE_MAX_Y = None
border_height = 40
SHOW_LAP_INFO = False  # barra LAP/TIME/BEST por baixo da janela Tracking
rectangle_width = 0

# Color range 
#LOWER_BLUE = np.array([100, 100, 50])
#UPPER_BLUE = np.array([140, 255, 255])

# Bolinha verde no centro do carro (posicao) e azul na frente (angulo)
LOWER_GREEN = np.array(GREEN_HSV_LOWER, dtype=np.uint8)
UPPER_GREEN = np.array(GREEN_HSV_UPPER, dtype=np.uint8)
LOWER_BLUE = np.array(BLUE_HSV_LOWER, dtype=np.uint8)
UPPER_BLUE = np.array(BLUE_HSV_UPPER, dtype=np.uint8)

# Validacao da bolinha da frente: tem de estar a esta distancia (m) da do centro
MARKER_MIN_DIST_M = 0.01
MARKER_MAX_DIST_M = 0.15
MARKER_MIN_AREA_PX = 3.0
front_marker_ok = False  # True se o angulo do ultimo frame veio das bolinhas

# Estimacao online do desvio do angulo das bolinhas (HeadingOffsetKF)
THETA_OFFSET_ESTIMATE = True
THETA_OFFSET_SEG_M = 0.08                 # comprimento de cada troco de deslocamento usado como medida
THETA_OFFSET_SEG_MAX_S = 2.0              # troco mais lento que isto e descartado
THETA_OFFSET_MIN_SAMPLES = 4
THETA_OFFSET_MAX_CURV = 1.5               # rad/m; trocos mais curvos sao descartados (raio < ~0.7 m)
THETA_OFFSET_POS_STD_M = 0.004            # ruido da posicao da bolinha verde
THETA_OFFSET_MARKER_STD_RAD = np.radians(3.0)   # ruido do angulo das bolinhas por frame
THETA_OFFSET_INIT_STD_RAD = np.radians(10.0)    # incerteza inicial do desvio
THETA_OFFSET_DRIFT_RAD_S = np.radians(0.2)      # deriva lenta permitida (random walk)
THETA_OFFSET_GATE_SIGMA = 3.0             # rejeita medidas fora de 3 sigma (ex: marcha-atras)
# Distancia do eixo traseiro a bolinha verde: em curva o centro nao anda na direcao
# do carro (deriva lateral beta = atan(d * curvatura)); isto compensa esse efeito.
MARKER_REAR_AXLE_DIST_M = 0.035

#Text constants
font = cv2.FONT_HERSHEY_SIMPLEX #font
fontScale = 0.5
thickness = 1
#blend alpha and beta
alpha = 0.3
beta = 1.0 - alpha

# UDP output
PC_IP = "127.0.0.1"
PC_PORT = 5005
SEND_UDP = True
TRACK_ID = 2

# Video recording
RECORD_OUTPUT_DIR = Path(__file__).with_name("recordings")
RECORD_FPS_FALLBACK = 20.0
RECORD_CODEC = "mp4v"
RECORD_LOG = True  # CSV (pose por frame) + JSON (pista e parametros) por cada video

#Get the overlay image
#Parameters: the shape of the video feed
def overlay(frame_shape):
    """
    Load the red overlay
    """
    global red

    if red is None:
        red = cv2.imread("Images/red.png")
        if red is not None:
            red = cv2.resize(red, (frame_shape[1], frame_shape[0]))


def transform_raw_point_to_processed(x_raw, y_raw):
    x_proc = float(x_raw) - float(CROP_WIDTH_START)
    y_proc = float(y_raw) - float(CROP_HEIGHT_START)

    x_proc *= RESIZE_FACTOR
    y_proc *= RESIZE_FACTOR

    x_proc = float(frame_width - 1) - x_proc
    y_proc = float(frame_height - 1) - y_proc

    if INVERT_IMAGE:
        if INVERT_FLIP_CODE in (1, -1):
            x_proc = float(frame_width - 1) - x_proc
        if INVERT_FLIP_CODE in (0, -1):
            y_proc = float(frame_height - 1) - y_proc

    return float(x_proc), float(y_proc)


def update_metric_reference():
    global REF_PX_ORIGIN, REF_PX_X_AXIS, PIXEL_TO_METER

    if CROP_WIDTH_START is None or frame_width <= 0 or frame_height <= 0:
        return

    REF_PX_ORIGIN = transform_raw_point_to_processed(*REF_PX_ORIGIN_RAW)
    REF_PX_X_AXIS = transform_raw_point_to_processed(*REF_PX_X_AXIS_RAW)

    dx_px = REF_PX_X_AXIS[0] - REF_PX_ORIGIN[0]
    if abs(dx_px) < 1e-9:
        raise ValueError("Referencia invalida apos transformacao do frame.")

    PIXEL_TO_METER = REF_X_METERS / dx_px


def px_to_m(x_px, y_px):
    if REF_PX_ORIGIN is None or PIXEL_TO_METER is None:
        return float("nan"), float("nan")

    x_m = (float(x_px) - REF_PX_ORIGIN[0]) * PIXEL_TO_METER
    y_m = (REF_PX_ORIGIN[1] - float(y_px)) * PIXEL_TO_METER
    return float(x_m), float(y_m)


def wrap_angle_pi(a):
    return float(np.arctan2(np.sin(a), np.cos(a)))


def angle_diff_abs(a, b):
    return abs(wrap_angle_pi(a - b))


class HeadingOffsetKF:
    """
    Filtro de Kalman (1 estado) para o desvio constante b entre o angulo das
    bolinhas e o angulo real do carro:   theta = theta_bolinhas + b

    Medida de b: num troco de THETA_OFFSET_SEG_M, a direcao da corda (inicio -> fim)
    e o angulo do carro a meio do troco, mais a deriva lateral do centro em curva:
        z = dir_corda - theta_bolinhas(meio) - atan(d_eixo * curvatura)
    O angulo a meio e a curvatura saem de uma reta ajustada a theta_bolinhas(s).
    """

    def __init__(self, b0_rad=0.0, std0_rad=THETA_OFFSET_INIT_STD_RAD):
        self.b = float(b0_rad)
        self.P = float(std0_rad) ** 2
        self.n_updates = 0
        self.n_rejected = 0
        self.t_last = None
        self.seg = None

    @property
    def std(self):
        return float(np.sqrt(self.P))

    def break_segment(self):
        self.seg = None

    def _start_segment(self, x, y, theta, t):
        self.seg = {"x0": x, "y0": y, "t0": t, "th0": theta, "s": [0.0], "dth": [0.0]}

    def observe(self, x, y, theta_markers, t):
        seg = self.seg
        if seg is None:
            self._start_segment(x, y, theta_markers, t)
            return

        if t - seg["t0"] > THETA_OFFSET_SEG_MAX_S:
            self._start_segment(x, y, theta_markers, t)
            return

        dx = x - seg["x0"]
        dy = y - seg["y0"]
        L = float(np.hypot(dx, dy))
        seg["s"].append(L)
        seg["dth"].append(wrap_angle_pi(theta_markers - seg["th0"]))

        if L < THETA_OFFSET_SEG_M:
            return

        # troco completo: o proximo comeca aqui
        self._start_segment(x, y, theta_markers, t)

        n = len(seg["s"])
        if n < THETA_OFFSET_MIN_SAMPLES:
            return

        # theta_bolinhas(s) ~ th0 + a + kappa * s
        s_arr = np.asarray(seg["s"])
        d_arr = np.asarray(seg["dth"])
        kappa, a = np.polyfit(s_arr, d_arr, 1)
        if abs(kappa) > THETA_OFFSET_MAX_CURV:
            return

        theta_mid = seg["th0"] + a + kappa * 0.5 * L
        beta = float(np.arctan(MARKER_REAR_AXLE_DIST_M * kappa))
        z = wrap_angle_pi(np.arctan2(dy, dx) - theta_mid - beta)

        # predicao (random walk) + atualizacao
        if self.t_last is not None:
            self.P += THETA_OFFSET_DRIFT_RAD_S ** 2 * max(0.0, t - self.t_last)
        self.t_last = t

        R = 2.0 * (THETA_OFFSET_POS_STD_M / L) ** 2 + THETA_OFFSET_MARKER_STD_RAD ** 2 / n
        S = self.P + R
        innov = wrap_angle_pi(z - self.b)
        if innov ** 2 > (THETA_OFFSET_GATE_SIGMA ** 2) * S:
            self.n_rejected += 1
            return

        K = self.P / S
        self.b = wrap_angle_pi(self.b + K * innov)
        self.P = (1.0 - K) * self.P
        self.n_updates += 1


heading_offset_kf = HeadingOffsetKF(np.radians(MARKER_THETA_OFFSET_DEG))


def update_raw_theta(x_m, y_m, t_now, front_m=None):
    """
    theta = direcao centro (verde) -> frente (azul), se a bolinha da frente foi vista.
    Sem ela, usa o deslocamento como antes (precisa que o carro ande).
    """
    global raw_theta_rad, raw_speed_m_s, raw_speed_anchor_pos_m, raw_speed_anchor_t
    global raw_speed_cycle_count, raw_theta_anchor_pos_m, raw_x_m, raw_y_m

    raw_x_m = float(x_m)
    raw_y_m = float(y_m)

    if raw_speed_anchor_pos_m is None or raw_speed_anchor_t is None:
        raw_speed_anchor_pos_m = (x_m, y_m)
        raw_speed_anchor_t = float(t_now)
        raw_speed_cycle_count = 0
    else:
        raw_speed_cycle_count += 1
        if raw_speed_cycle_count >= RAW_SPEED_UPDATE_CYCLES:
            dx_speed = x_m - raw_speed_anchor_pos_m[0]
            dy_speed = y_m - raw_speed_anchor_pos_m[1]
            dt_speed = max(1e-6, float(t_now - raw_speed_anchor_t))
            raw_speed_m_s = float(np.hypot(dx_speed, dy_speed)) / dt_speed
            raw_speed_anchor_pos_m = (x_m, y_m)
            raw_speed_anchor_t = float(t_now)
            raw_speed_cycle_count = 0

    if front_m is not None:
        theta_markers = float(np.arctan2(front_m[1] - y_m, front_m[0] - x_m))
        if THETA_OFFSET_ESTIMATE:
            heading_offset_kf.observe(x_m, y_m, theta_markers, t_now)
        raw_theta_rad = wrap_angle_pi(theta_markers + heading_offset_kf.b)
        raw_theta_anchor_pos_m = (x_m, y_m)
        return float(raw_theta_rad)

    heading_offset_kf.break_segment()
    if raw_theta_anchor_pos_m is None:
        raw_theta_anchor_pos_m = (x_m, y_m)
    else:
        dx = x_m - raw_theta_anchor_pos_m[0]
        dy = y_m - raw_theta_anchor_pos_m[1]
        step_m = float(np.hypot(dx, dy))

        if step_m >= RAW_THETA_MIN_UPDATE_M:
            theta_raw = float(np.arctan2(dy, dx))
            theta_alt = wrap_angle_pi(theta_raw + np.pi)

            if angle_diff_abs(theta_raw, raw_theta_rad) <= angle_diff_abs(theta_alt, raw_theta_rad):
                raw_theta_rad = theta_raw
            else:
                raw_theta_rad = theta_alt

            raw_theta_anchor_pos_m = (x_m, y_m)

    return float(raw_theta_rad)


def m_to_px(x_m, y_m):
    if REF_PX_ORIGIN is None or PIXEL_TO_METER is None:
        return float("nan"), float("nan")

    x_px = REF_PX_ORIGIN[0] + (float(x_m) / PIXEL_TO_METER)
    y_px = REF_PX_ORIGIN[1] - (float(y_m) / PIXEL_TO_METER)
    return float(x_px), float(y_px)


def build_rounded_polyline(points, corner_radius=0.08, corner_samples=10, closed=True):
    n = len(points)
    if n < 2:
        return list(points)
    if n == 2:
        return list(points)

    pts = [np.array(p, dtype=float) for p in points]

    if not closed:
        out_open = [tuple(pts[0])]
        for i in range(1, n - 1):
            p_prev = pts[i - 1]
            p_curr = pts[i]
            p_next = pts[i + 1]
            v_in = p_curr - p_prev
            v_out = p_next - p_curr
            len_in = float(np.linalg.norm(v_in))
            len_out = float(np.linalg.norm(v_out))
            if len_in < 1e-9 or len_out < 1e-9:
                out_open.append(tuple(p_curr))
                continue
            u_in = v_in / len_in
            u_out = v_out / len_out
            d = min(corner_radius, 0.45 * len_in, 0.45 * len_out)
            p_start = p_curr - u_in * d
            p_end = p_curr + u_out * d
            out_open.append(tuple(p_start))
            for t in np.linspace(0.0, 1.0, corner_samples + 2)[1:-1]:
                pt = ((1.0 - t) ** 2) * p_start + 2.0 * (1.0 - t) * t * p_curr + (t ** 2) * p_end
                out_open.append((float(pt[0]), float(pt[1])))
            out_open.append(tuple(p_end))
        out_open.append(tuple(pts[-1]))
        return out_open

    out = []
    for i in range(n):
        p_prev = pts[(i - 1) % n]
        p_curr = pts[i]
        p_next = pts[(i + 1) % n]
        v_in = p_curr - p_prev
        v_out = p_next - p_curr
        len_in = float(np.linalg.norm(v_in))
        len_out = float(np.linalg.norm(v_out))
        if len_in < 1e-9 or len_out < 1e-9:
            continue
        u_in = v_in / len_in
        u_out = v_out / len_out
        d = min(corner_radius, 0.45 * len_in, 0.45 * len_out)
        p_start = p_curr - u_in * d
        p_end = p_curr + u_out * d
        out.append((float(p_start[0]), float(p_start[1])))
        for t in np.linspace(0.0, 1.0, corner_samples + 2)[1:-1]:
            pt = ((1.0 - t) ** 2) * p_start + 2.0 * (1.0 - t) * t * p_curr + (t ** 2) * p_end
            out.append((float(pt[0]), float(pt[1])))
        out.append((float(p_end[0]), float(p_end[1])))

    return out


def _editable_point_sets():
    sets = [
        ("track", TRACK_POINTS_M),
        ("inner", BARRIER_INNER_M),
        ("outer", BARRIER_OUTER_M),
    ]
    for k, island in enumerate(BARRIER_INNER_EXTRA_M):
        sets.append((f"inner_extra{k}", island))
    return sets


def _points_by_name(points_name):
    return dict(_editable_point_sets()).get(points_name)


def _round_edit_coord(value):
    value = round(float(value), 2)
    if abs(value) < 0.005:
        value = 0.0
    return value


def _find_nearest_control_point(x_px, y_px):
    if REF_PX_ORIGIN is None or PIXEL_TO_METER is None:
        return None

    best = None
    best_dist = float("inf")
    px_per_meter = abs(1.0 / PIXEL_TO_METER)

    for points_name, points in _editable_point_sets():
        for idx, (x_m, y_m) in enumerate(points):
            px, py = m_to_px(x_m, y_m)
            if not (np.isfinite(px) and np.isfinite(py)):
                continue

            dist = float(np.hypot(float(x_px) - px, float(y_px) - py))
            if dist <= POINT_PICK_RADIUS_PX and dist < best_dist:
                best_dist = dist
                best = (points_name, idx)

    for idx, obstacle in enumerate(OBSTACLES_M):
        ox_px, oy_px = m_to_px(float(obstacle["x"]), float(obstacle["y"]))
        if not (np.isfinite(ox_px) and np.isfinite(oy_px)):
            continue

        radius_px = max(1, int(round(float(obstacle["r"]) * px_per_meter)))
        pick_radius_px = max(POINT_PICK_RADIUS_PX, radius_px)
        dist = float(np.hypot(float(x_px) - ox_px, float(y_px) - oy_px))
        if dist <= pick_radius_px and dist < best_dist:
            best_dist = dist
            best = ("obstacle", idx)

    return best


def _move_selected_control_point(x_px, y_px):
    global edited_points_dirty

    if edit_drag_target is None:
        return

    if y_px < 0 or y_px >= frame_height or x_px < 0 or x_px >= frame_width:
        return

    x_m, y_m = px_to_m(x_px, y_px)
    if not (np.isfinite(x_m) and np.isfinite(y_m)):
        return

    points_name, idx = edit_drag_target
    if points_name == "obstacle":
        obstacle = OBSTACLES_M[idx]
        obstacle["x"] = _round_edit_coord(x_m)
        obstacle["y"] = _round_edit_coord(y_m)
        edited_points_dirty = True
        invalidate_static_overlay()
        return

    points = _points_by_name(points_name)
    if points is None:
        return

    points[idx] = (
        _round_edit_coord(x_m),
        _round_edit_coord(y_m),
    )
    edited_points_dirty = True
    invalidate_static_overlay()


def edit_control_points(event, x, y, flags, param):
    global edit_drag_target

    if event == cv2.EVENT_LBUTTONDOWN:
        edit_drag_target = _find_nearest_control_point(x, y)
        _move_selected_control_point(x, y)
    elif event == cv2.EVENT_MOUSEMOVE and edit_drag_target is not None:
        _move_selected_control_point(x, y)
    elif event == cv2.EVENT_LBUTTONUP:
        _move_selected_control_point(x, y)
        edit_drag_target = None


def _format_coord(value):
    # 3 casas (pistas sim), sem o zero final: 0.520 -> 0.52
    text = f"{float(value):.3f}"
    return text[:-1] if text.endswith("0") else text


def _format_points_block(points, indent=""):
    lines = ["["]
    for x_m, y_m in points:
        lines.append(f"{indent}    ({_format_coord(x_m)}, {_format_coord(y_m)}),")
    lines.append(f"{indent}]")
    return "\n".join(lines)


def _format_islands_block(islands):
    lines = ["["]
    for island in islands:
        lines.append(f"    {_format_points_block(island, indent='    ')},")
    lines.append("]")
    return "\n".join(lines)


def _format_obstacles_block(obstacles):
    lines = ["["]
    for obstacle in obstacles:
        lines.append(
            "    "
            f'{{"x": {_format_coord(obstacle["x"])}, '
            f'"y": {_format_coord(obstacle["y"])}, '
            f'"r": {_format_coord(obstacle["r"])}}},'
        )
    lines.append("]")
    return "\n".join(lines)


def _replace_points_block(text, name, points, followed_by=None, formatter=None):
    replacement = f"{name} = {(formatter or _format_points_block)(points)}"
    pattern = rf"{name}\s*=\s*\[\n.*?\n\]"
    if followed_by is not None:
        pattern += rf"(?=\s*{followed_by})"
    text, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError(f"Nao encontrei o bloco {name} em {SHARED_CONFIG_PATH.name}.")
    return text


def _replace_points_block_before_marker(text, name, points, marker):
    marker_idx = text.find(marker)
    if marker_idx < 0:
        raise RuntimeError(f"Nao encontrei o marcador {marker} em {SHARED_CONFIG_PATH.name}.")

    block_start = text.rfind(name, 0, marker_idx)
    if block_start < 0:
        raise RuntimeError(f"Nao encontrei o bloco ativo {name} em {SHARED_CONFIG_PATH.name}.")

    block_end = text.find("\n]", block_start, marker_idx)
    if block_end < 0:
        raise RuntimeError(f"Nao encontrei o fim do bloco ativo {name} em {SHARED_CONFIG_PATH.name}.")
    block_end += len("\n]")

    replacement = f"{name} = {_format_points_block(points)}"
    return text[:block_start] + replacement + text[block_end:]


def _replace_obstacles_block(text, name, obstacles):
    replacement = f"{name} = {_format_obstacles_block(obstacles)}"
    pattern = rf"{name}\s*=\s*\[\n.*?\n\]"
    text, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError(f"Nao encontrei o bloco {name} em {SHARED_CONFIG_PATH.name}.")
    return text


def save_control_points_to_shared_config():
    global edited_points_dirty

    text = SHARED_CONFIG_PATH.read_text(encoding="utf-8")
    text = _replace_points_block_before_marker(
        text,
        "TRACK_POINTS_M",
        TRACK_POINTS_M,
        marker="BARRIER_ROUND_CORNER_RADIUS_M",
    )
    text = _replace_points_block(text, "BARRIER_INNER_M", BARRIER_INNER_M)
    text = _replace_points_block(
        text, "BARRIER_INNER_EXTRA_M", BARRIER_INNER_EXTRA_M, formatter=_format_islands_block
    )
    text = _replace_points_block(text, "BARRIER_OUTER_M", BARRIER_OUTER_M)
    text = _replace_obstacles_block(text, "OBSTACLES_M", OBSTACLES_M)
    SHARED_CONFIG_PATH.write_text(text, encoding="utf-8")
    edited_points_dirty = False
    print(f"Pontos e obstaculos guardados em {SHARED_CONFIG_PATH.name}.")


def handle_tracking_key(key, tracking_frame=None):
    if key == 13:
        if tracking_frame is not None:
            save_tracking_frame_pdf(tracking_frame)
        else:
            print("No tracking frame available to save yet.")
        return False

    if key in (ord("q"), ord("Q")):
        if edited_points_dirty:
            print("Tens alteracoes por guardar. Carrega em S para guardar, ou Esc para sair sem guardar.")
            return False
        return True

    if key == 27:
        return True

    if key in (ord("s"), ord("S")):
        save_control_points_to_shared_config()

    if key in (ord("o"), ord("O")):
        save_theta_offset_to_shared_config()

    return False


def save_theta_offset_to_shared_config():
    offset_deg = float(np.degrees(heading_offset_kf.b))
    text = SHARED_CONFIG_PATH.read_text(encoding="utf-8")
    text, count = re.subn(
        r"^MARKER_THETA_OFFSET_DEG\s*=\s*[^\n]*",
        f"MARKER_THETA_OFFSET_DEG = {offset_deg:.2f}",
        text,
        count=1,
        flags=re.M,
    )
    if count != 1:
        print(f"Nao encontrei MARKER_THETA_OFFSET_DEG em {SHARED_CONFIG_PATH.name}.")
        return
    SHARED_CONFIG_PATH.write_text(text, encoding="utf-8")
    print(
        f"Desvio do angulo {offset_deg:+.2f} deg "
        f"(+-{np.degrees(heading_offset_kf.std):.2f}) guardado em {SHARED_CONFIG_PATH.name}."
    )


def _points_m_to_px_array(points_m):
    pts = np.asarray(points_m, dtype=float).reshape(-1, 2)
    x_px = REF_PX_ORIGIN[0] + pts[:, 0] / PIXEL_TO_METER
    y_px = REF_PX_ORIGIN[1] - pts[:, 1] / PIXEL_TO_METER
    return np.round(np.column_stack([x_px, y_px])).astype(np.int32)


def _build_static_overlay():
    """Pista, barreiras e obstaculos ja em pixeis (so muda ao editar pontos)."""
    lines = []   # (pontos da curva, pontos de controlo, cor, raio dos pontos)

    path_m = build_rounded_polyline(
        list(TRACK_POINTS_M),
        corner_radius=ROUND_CORNER_RADIUS_M,
        corner_samples=ROUND_CORNER_SAMPLES,
        closed=True
    )
    lines.append((_points_m_to_px_array(path_m), _points_m_to_px_array(TRACK_POINTS_M), (255, 0, 0), 4))

    for _, barrier_m in _editable_point_sets()[1:]:
        rounded_m = build_rounded_polyline(
            list(barrier_m),
            corner_radius=BARRIER_ROUND_CORNER_RADIUS_M,
            corner_samples=BARRIER_ROUND_CORNER_SAMPLES,
            closed=True
        )
        lines.append((_points_m_to_px_array(rounded_m), _points_m_to_px_array(barrier_m), (0, 0, 255), 3))

    px_per_meter = abs(1.0 / PIXEL_TO_METER)
    obstacles = []
    for obstacle in OBSTACLES_M:
        center = _points_m_to_px_array([(obstacle["x"], obstacle["y"])])[0]
        radius_px = max(1, int(round(float(obstacle["r"]) * px_per_meter)))
        obstacles.append(((int(center[0]), int(center[1])), radius_px))

    return lines, obstacles


def invalidate_static_overlay():
    global static_overlay_version
    static_overlay_version += 1


def draw_static_overlay(img):
    """Desenha pista, barreiras e obstaculos; a geometria e calculada uma unica vez."""
    if REF_PX_ORIGIN is None or PIXEL_TO_METER is None:
        return

    key = (static_overlay_version, REF_PX_ORIGIN, PIXEL_TO_METER)
    if _static_overlay_cache["key"] != key:
        _static_overlay_cache["key"] = key
        _static_overlay_cache["data"] = _build_static_overlay()

    lines, obstacles = _static_overlay_cache["data"]
    for curve_px, control_px, color, point_radius in lines:
        if len(curve_px) >= 2:
            cv2.polylines(img, [curve_px], True, color, 2, cv2.LINE_AA)
        for cx, cy in control_px:
            cv2.circle(img, (int(cx), int(cy)), point_radius, color, -1, cv2.LINE_AA)

    for center, radius_px in obstacles:
        cv2.circle(img, center, radius_px, (0, 140, 255), 2, cv2.LINE_AA)
        cv2.circle(img, center, 2, (0, 140, 255), -1, cv2.LINE_AA)


def build_udp_payload(frame_counter, x_px, y_px, x_m, y_m, timing_ms=None, t_capture=None):
    theta_rad = float(raw_theta_rad)
    theta_deg = float(np.degrees(theta_rad))
    speed_m_s = float(raw_speed_m_s)
    t_wall = time.time()

    return {
        "t": t_wall,
        "t_wall": t_wall,
        # instante (time.time() deste PC) em que o frame chegou do cap.read();
        # o runner usa-o para compensar o atraso da visao
        "t_capture": float(t_wall if t_capture is None else t_capture),
        "frame": int(frame_counter),
        "timing_ms": timing_ms or {},
        "tracks": [{
            "id": int(TRACK_ID),
            "x_px": float(x_px),
            "y_px": float(y_px),
            "x_m": float(x_m),
            "y_m": float(y_m),
            "vx_px_s": 0.0,
            "vy_px_s": 0.0,
            "vx_m_s": 0.0,
            "vy_m_s": 0.0,
            "ax_px_s2": 0.0,
            "ay_px_s2": 0.0,
            "ax_m_s2": 0.0,
            "ay_m_s2": 0.0,
            "speed_m_s": speed_m_s,
            "theta_rad": theta_rad,
            "theta_deg": theta_deg,
            "theta_src": "markers" if front_marker_ok else "motion",
            "theta_offset_rad": float(heading_offset_kf.b),
            "theta_offset_std_rad": float(heading_offset_kf.std),
            "mode": "MEAS_VISION",
            "missed": 0,
            "source": "track1"
        }]
    }

def get_recording_fps(cap):
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not np.isfinite(fps) or fps <= 1.0:
        return RECORD_FPS_FALLBACK
    return float(fps)


class WindowRecorder:
    def __init__(self, window_name, file_label, fps, timestamp):
        self.window_name = window_name
        self.path = RECORD_OUTPUT_DIR / f"track1_{file_label}_{timestamp}.mp4"
        self.fps = float(fps)
        self.writer = None
        self.size = None
        self.enabled = True

    def _open(self, frame):
        RECORD_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        height, width = frame.shape[:2]
        width -= width % 2
        height -= height % 2
        self.size = (width, height)
        fourcc = cv2.VideoWriter_fourcc(*RECORD_CODEC)
        self.writer = cv2.VideoWriter(str(self.path), fourcc, self.fps, self.size)

        if not self.writer.isOpened():
            self.writer.release()
            self.writer = None
            self.enabled = False
            print(f"Warning: nao consegui abrir a gravacao de {self.window_name}: {self.path}")
            return

        print(f"A gravar {self.window_name} em {self.path}")

    def write(self, frame):
        if not self.enabled or frame is None:
            return

        if self.writer is None:
            self._open(frame)
            if self.writer is None:
                return

        width, height = self.size
        if frame.shape[1] != width or frame.shape[0] != height:
            frame = cv2.resize(frame, self.size)

        self.writer.write(frame)

    def release(self):
        if self.writer is not None:
            self.writer.release()
            self.writer = None
            print(f"Gravacao {self.window_name} guardada em {self.path}")


def _round_list(points, nd=4):
    return [[round(float(x), nd), round(float(y), nd)] for x, y in points]


def _geometry_snapshot():
    """Caminho, barreiras e obstaculos em metros, tal como o controlador os usa."""
    cp = CONTROLLER_PARAMS
    path_rounded = build_rounded_polyline(
        list(TRACK_POINTS_M),
        corner_radius=cp["path_corner_radius_m"],
        corner_samples=cp["path_corner_samples"],
        closed=True,
    )
    path = {
        "control_points": _round_list(TRACK_POINTS_M),
        "rounded": _round_list(path_rounded),
        "corner_radius_m": cp["path_corner_radius_m"],
        "corner_samples": cp["path_corner_samples"],
    }
    if build_spline_path is not None:
        waypoints = list(path_rounded)
        if waypoints and waypoints[0] != waypoints[-1]:
            waypoints.append(waypoints[0])
        px, py, pyaw, s = build_spline_path(waypoints, ds=cp["path_ds"])
        path["spline"] = {
            "ds": cp["path_ds"],
            "x": [round(float(v), 4) for v in px],
            "y": [round(float(v), 4) for v in py],
            "yaw": [round(float(v), 4) for v in pyaw],
            "s": [round(float(v), 4) for v in s],
        }

    def _barrier(points):
        return {
            "control_points": _round_list(points),
            "rounded": _round_list(build_rounded_polyline(
                list(points),
                corner_radius=BARRIER_ROUND_CORNER_RADIUS_M,
                corner_samples=BARRIER_ROUND_CORNER_SAMPLES,
                closed=True,
            )),
        }

    return {
        "path": path,
        "barriers": {
            "corner_radius_m": BARRIER_ROUND_CORNER_RADIUS_M,
            "corner_samples": BARRIER_ROUND_CORNER_SAMPLES,
            "inner": _barrier(BARRIER_INNER_M),
            "inner_extra": [_barrier(island) for island in BARRIER_INNER_EXTRA_M],
            "outer": _barrier(BARRIER_OUTER_M),
        },
        "obstacles": [
            {"x": float(o["x"]), "y": float(o["y"]), "r": float(o["r"])} for o in OBSTACLES_M
        ],
    }


class VideoRunLog:
    """
    Log de cada gravacao, ao lado dos .mp4 em recordings/:
      track1_log_<ts>.csv  -> 1 linha por frame gravado (video_frame = indice no .mp4)
      track1_meta_<ts>.json -> caminho, barreiras, obstaculos e parametros do controlador
    O t_capture e o mesmo do UDP: junta-se com logs/run_*.csv do runner por essa coluna.
    """

    COLUMNS = [
        "video_frame", "frame", "t_capture", "t_rel", "detected",
        "x_m", "y_m", "theta_rad", "theta_deg", "theta_src", "speed_m_s",
        "theta_offset_rad", "x_px", "y_px",
    ]

    def __init__(self, timestamp, fps, video_paths):
        RECORD_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        self.csv_path = RECORD_OUTPUT_DIR / f"track1_log_{timestamp}.csv"
        self.meta_path = RECORD_OUTPUT_DIR / f"track1_meta_{timestamp}.json"
        self.n_frames = 0
        self.t0 = None
        self.overlay_version0 = static_overlay_version
        self.meta = {
            "timestamp": timestamp,
            "t_start_wall": time.time(),
            "videos": [str(Path(p).name) for p in video_paths],
            "csv": self.csv_path.name,
            "video_fps_nominal": float(fps),
            "units": "metros, radianos, segundos (t_capture = time.time() do PC)",
            "controller_runner": "run_real_esp_wifi.py (le CONTROLLER_PARAMS do shared_config.py)",
            "controller_params": dict(CONTROLLER_PARAMS),
            "robot_ellipse_ab_m": [ROBOT_ELLIPSE_A_M, ROBOT_ELLIPSE_B_M],
            "vision": {
                "marker_theta_offset_init_deg": float(MARKER_THETA_OFFSET_DEG),
                "theta_offset_estimate": bool(THETA_OFFSET_ESTIMATE),
                "camera_index": CAMERA_INDEX,
                "frame_size_px": [int(frame_width), int(frame_height)],
                "crop_px": [CROP_WIDTH_START, CROP_WIDTH_END, CROP_HEIGHT_START, CROP_HEIGHT_END],
                "resize_factor": RESIZE_FACTOR,
                "ref_px_origin": list(REF_PX_ORIGIN) if REF_PX_ORIGIN else None,
                "pixel_to_meter": PIXEL_TO_METER,
            },
            "geometry": _geometry_snapshot(),
        }
        self._write_meta()
        self.file = open(self.csv_path, "w", encoding="utf-8", newline="")
        self.file.write(",".join(self.COLUMNS) + "\n")
        print(f"Log do video em {self.csv_path} e {self.meta_path}")

    def _write_meta(self):
        with open(self.meta_path, "w", encoding="utf-8") as f:
            json.dump(self.meta, f, indent=1)

    def log(self, frame_counter, t_capture, detected, x_m=float("nan"), y_m=float("nan"),
            x_px=float("nan"), y_px=float("nan")):
        if self.t0 is None:
            self.t0 = t_capture
        if detected:
            theta = float(raw_theta_rad)
            row = [
                self.n_frames, frame_counter, f"{t_capture:.4f}", f"{t_capture - self.t0:.4f}", 1,
                f"{x_m:.4f}", f"{y_m:.4f}", f"{theta:.4f}", f"{np.degrees(theta):.2f}",
                "markers" if front_marker_ok else "motion", f"{raw_speed_m_s:.4f}",
                f"{heading_offset_kf.b:.4f}", f"{x_px:.1f}", f"{y_px:.1f}",
            ]
        else:
            row = [self.n_frames, frame_counter, f"{t_capture:.4f}", f"{t_capture - self.t0:.4f}", 0]
            row += [""] * (len(self.COLUMNS) - len(row))
        self.file.write(",".join(str(v) for v in row) + "\n")
        self.n_frames += 1

    def close(self):
        if self.file is None:
            return
        self.file.close()
        self.file = None
        self.meta["t_end_wall"] = time.time()
        self.meta["n_frames"] = self.n_frames
        self.meta["vision"]["marker_theta_offset_final_deg"] = float(np.degrees(heading_offset_kf.b))
        self.meta["vision"]["marker_theta_offset_final_std_deg"] = float(np.degrees(heading_offset_kf.std))
        if static_overlay_version != self.overlay_version0:
            # pontos editados com o rato durante a gravacao: guarda tambem a versao final
            self.meta["geometry_end"] = _geometry_snapshot()
        self._write_meta()
        print(f"Log do video guardado em {self.csv_path} ({self.n_frames} frames)")


def default_crop(raw_width, raw_height):
    """Corte por defeito (x0, x1, y0, y1) em pixeis do frame original."""
    return (
        raw_width//3 - 160,
        raw_width//3*2 + 150,
        0,
        raw_height//10*CROP_HEIGHT_FACTOR + 75,
    )


#Let the user draw the crop rectangle on the raw camera frame
#Parameters: video capture
def select_crop(cap):

    global CROP_WIDTH_START, CROP_WIDTH_END, CROP_HEIGHT_START, CROP_HEIGHT_END

    ret, frame = cap.read()
    if not ret:
        check(cap)
    frame = undistort_frame(frame)

    raw_height, raw_width = frame.shape[:2]
    x0, x1, y0, y1 = default_crop(raw_width, raw_height)

    preview = frame.copy()
    cv2.rectangle(preview, (x0, y0), (x1 - 1, y1 - 1), (0, 255, 255), 2)
    cv2.putText(preview, "Desenha o corte e carrega Enter (C = manter o amarelo)",
                (10, 25), font, 0.6, (0, 255, 255), 2, cv2.LINE_AA)

    print(f"Frame da camera: {raw_width}x{raw_height}. Desenha o corte e carrega Enter/Espaco; C mantem o corte por defeito.")
    x, y, w, h = cv2.selectROI("Crop", preview, showCrosshair=False)
    cv2.destroyWindow("Crop")

    if w > 0 and h > 0:
        x0, x1, y0, y1 = int(x), int(x + w), int(y), int(y + h)

    CROP_WIDTH_START, CROP_WIDTH_END = x0, x1
    CROP_HEIGHT_START, CROP_HEIGHT_END = y0, y1
    print(f"Corte: x=[{x0}, {x1}] y=[{y0}, {y1}]")


#Process the frame
#Parameters: Frame to process
#Returns: The frame cropped and rotated
def process_frame(frame):

    global CROP_WIDTH_START, CROP_WIDTH_END, CROP_HEIGHT_START, CROP_HEIGHT_END, frame_width, frame_height, rectangle_width, raw_frame_width, raw_frame_height
    
    frame = undistort_frame(frame)
    raw_frame_height, raw_frame_width = frame.shape[:2]
    frame_height, frame_width = frame.shape[:2]

    #Get crop dimensions
    if CROP_WIDTH_START is None:
        CROP_WIDTH_START, CROP_WIDTH_END, CROP_HEIGHT_START, CROP_HEIGHT_END = default_crop(frame_width, frame_height)
    
    #Crop and rotate the frame
    frame = frame[CROP_HEIGHT_START:CROP_HEIGHT_END, CROP_WIDTH_START:CROP_WIDTH_END]
    
    #Resize and rotate
    frame = cv2.resize(frame, None, fx=RESIZE_FACTOR, fy=RESIZE_FACTOR)
    frame = cv2.rotate(frame, cv2.ROTATE_180)
    if INVERT_IMAGE:
        frame = cv2.flip(frame, INVERT_FLIP_CODE)

    #Define border constants
    frame_height, frame_width = frame.shape[:2]
    rectangle_width = frame_width//3
    update_metric_reference()
    
    return frame

#Apply bottom border to the window
#Parameters: window with car centre and a list to lap info
#Return: Img with border and lap info
def apply_border(img, phrases):

    global border_height, frame_height, frame_width, rectangle_width

    #Add bottom border
    img = cv2.copyMakeBorder(img, 0, border_height, 0 , 0,
                             cv2.BORDER_CONSTANT, (0, 0, 0))

    for i in range(3):

        x_start = i * rectangle_width
        if i < 2:
            x_end = (i + 1) * rectangle_width
        else:
            frame_width - 2  # Last section stops at the end
    
        top_left_corner = (x_start, frame_height)
        bottom_right_corner = (x_end, frame_height + border_height - 2)
        
        #Draw rectangle
        cv2.rectangle(img, top_left_corner, bottom_right_corner,
                      (255, 255, 255), 2)
        
        # Put text inside rectangle
        (text_width, text_height), _ = cv2.getTextSize(phrases[i], font, fontScale, thickness)

        #Calculate centered text position
        text_x = x_start + (rectangle_width - text_width) // 2
        text_y = frame_height + (border_height + text_height) // 2 - 4

        #Add text
        cv2.putText(img, phrases[i], (text_x, text_y), font, fontScale,
                    (255, 255, 255), thickness, cv2.LINE_AA)

    return img

#Extracts the track's edges
#Parameters: Frame with the track
#Returns: The limits of the track and the same frame grayscaled, but with the edges found highlighted in white
def limits (frame):

    if frame is None:
        return -1

    #Convert to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    #Apply histogram equalization to boost contrast
    gray = cv2.equalizeHist(gray)
    #Apply blur
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    #Use Canny edge detection
    edged = cv2.Canny(blurred, 70, 170, apertureSize=3)

    #Close all contours
    edged = cv2.morphologyEx(edged, cv2.MORPH_CLOSE, kernel)

    #Find all contours
    contours, _ = cv2.findContours(edged, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return frame, None

    #Extract largest contour
    largest = max(contours, key=cv2.contourArea)

    #Draw on frame copy
    img = frame.copy()
    cv2.drawContours(img, [largest], -1, (0, 0, 255), 2)
        
    return img, largest


def _format_hsv_tuple(values):
    return f"({int(values[0])}, {int(values[1])}, {int(values[2])})"


def _upsert_config_constant(text, name, value_text, after_name):
    replacement = f"{name} = {value_text}"
    pattern = rf"^{name}\s*=\s*[\(\[][^\n]*[\)\]]"
    text, count = re.subn(pattern, replacement, text, count=1, flags=re.M)
    if count == 1:
        return text

    after_pattern = rf"^({after_name}\s*=\s*[^\n]*\n)"
    text, count = re.subn(
        after_pattern,
        lambda match: match.group(1) + replacement + "\n",
        text,
        count=1,
        flags=re.M,
    )
    if count == 1:
        return text

    return text.rstrip() + "\n\n" + replacement + "\n"


def save_hsv_to_shared_config(prefix, lower, upper, after_name):
    text = SHARED_CONFIG_PATH.read_text(encoding="utf-8")
    text = _upsert_config_constant(
        text,
        f"{prefix}_HSV_LOWER",
        _format_hsv_tuple(lower),
        after_name=after_name,
    )
    text = _upsert_config_constant(
        text,
        f"{prefix}_HSV_UPPER",
        _format_hsv_tuple(upper),
        after_name=f"{prefix}_HSV_LOWER",
    )
    SHARED_CONFIG_PATH.write_text(text, encoding="utf-8")
    print(f"{prefix} HSV saved to {SHARED_CONFIG_PATH.name}.")


def save_frame_pdf(frame, filename_prefix, title):
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    pdf_path = Path(__file__).with_name(f"{filename_prefix}_{timestamp}.pdf")
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    height, width = rgb_frame.shape[:2]
    fig_width = max(6.0, width / 120.0)
    fig_height = max(4.0, height / 120.0)
    fig, ax = plt.subplots(figsize=(fig_width, fig_height))
    ax.imshow(rgb_frame)
    ax.set_title(title, fontsize=10)
    ax.axis("off")
    fig.tight_layout(pad=0.2)
    fig.savefig(pdf_path, format="pdf", bbox_inches="tight")
    plt.close(fig)
    print(f"{title} saved to {pdf_path}.")


def save_tracking_frame_pdf(frame):
    if frame_height > 0 and frame.shape[0] > frame_height:
        frame = frame[:frame_height, :]
    save_frame_pdf(frame, "tracking_frame", "Tracking frame")


def calibrate_color(cap, window_name, description, lower_init, upper_init, prefix, after_name):
    """Janela de calibracao HSV; devolve (lower, upper) e guarda no shared_config."""

    def _nothing(_value):
        pass

    cv2.namedWindow(window_name)
    cv2.createTrackbar("H min", window_name, int(lower_init[0]), 179, _nothing)
    cv2.createTrackbar("H max", window_name, int(upper_init[0]), 179, _nothing)
    cv2.createTrackbar("S min", window_name, int(lower_init[1]), 255, _nothing)
    cv2.createTrackbar("S max", window_name, int(upper_init[1]), 255, _nothing)
    cv2.createTrackbar("V min", window_name, int(lower_init[2]), 255, _nothing)
    cv2.createTrackbar("V max", window_name, int(upper_init[2]), 255, _nothing)

    print(f"{window_name}: adjust the HSV controls until the mask captures only {description}.")
    print("Enter/Space confirms the values. Q exits.")

    while True:
        ret, frame = cap.read()
        if not ret:
            check(cap)

        frame = process_frame(frame)
        h_min = cv2.getTrackbarPos("H min", window_name)
        h_max = cv2.getTrackbarPos("H max", window_name)
        s_min = cv2.getTrackbarPos("S min", window_name)
        s_max = cv2.getTrackbarPos("S max", window_name)
        v_min = cv2.getTrackbarPos("V min", window_name)
        v_max = cv2.getTrackbarPos("V max", window_name)

        lower = np.array([
            min(h_min, h_max),
            min(s_min, s_max),
            min(v_min, v_max),
        ], dtype=np.uint8)
        upper = np.array([
            max(h_min, h_max),
            max(s_min, s_max),
            max(v_min, v_max),
        ], dtype=np.uint8)

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, lower, upper)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        masked = cv2.bitwise_and(frame, frame, mask=mask)
        preview = np.hstack((frame, masked))
        cv2.putText(preview, f"Mascara: so {description}", (10, 25),
                    font, 0.6, (0, 255, 255), 2, cv2.LINE_AA)
        cv2.imshow(window_name, preview)

        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), ord("Q")):
            cv2.destroyWindow(window_name)
            cap.release()
            cv2.destroyAllWindows()
            exit()

        if key in (13, 32):
            save_hsv_to_shared_config(prefix, lower, upper, after_name)
            cv2.destroyWindow(window_name)
            print(f"{prefix} calibrated: lower={lower.tolist()} upper={upper.tolist()}")
            return lower, upper


def calibrate_marker_colors(cap):
    global LOWER_GREEN, UPPER_GREEN, LOWER_BLUE, UPPER_BLUE

    LOWER_GREEN, UPPER_GREEN = calibrate_color(
        cap, "Green calibration (centro)", "a bolinha verde (centro do carro)",
        LOWER_GREEN, UPPER_GREEN, prefix="GREEN", after_name="ROBOT_ELLIPSE_B_M",
    )
    LOWER_BLUE, UPPER_BLUE = calibrate_color(
        cap, "Blue calibration (frente)", "a bolinha azul (frente do carro)",
        LOWER_BLUE, UPPER_BLUE, prefix="BLUE", after_name="GREEN_HSV_UPPER",
    )


#Get coordinates of the finishing line
def set_finishing_line(event, x, y, flags, param):

    global click_count, FINISHING_LINE_MIN_X, FINISHING_LINE_MAX_X, FINISHING_LINE_MIN_Y, FINISHING_LINE_MAX_Y

    if event == cv2.EVENT_LBUTTONDOWN:

        #If this is first set of coordinates
        if click_count == 0:

            FINISHING_LINE_MIN_X = x
            FINISHING_LINE_MIN_Y = y
            click_count += 1
            print("Select the bottom right corner of the finishing line")
        
        #If this is the second set of coordinates        
        elif click_count == 1:

            FINISHING_LINE_MAX_X = x
            FINISHING_LINE_MAX_Y = y
            click_count += 1

def color_contours(frame, lower, upper):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lower, upper)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)
    return contours


#Find the front (blue) marker next to the car centre
#Parameters: frame, car centre in pixels
#Returns: (x, y) of the front marker in pixels, or None
def front_marker(frame, x_c, y_c):

    if frame is None or PIXEL_TO_METER is None:
        return None

    px_per_meter = abs(1.0 / PIXEL_TO_METER)
    min_dist_px = MARKER_MIN_DIST_M * px_per_meter
    max_dist_px = MARKER_MAX_DIST_M * px_per_meter

    best = None
    best_area = 0.0
    for c in color_contours(frame, LOWER_BLUE, UPPER_BLUE):
        M = cv2.moments(c)
        if M["m00"] < MARKER_MIN_AREA_PX:
            continue
        fx = M["m10"] / M["m00"]
        fy = M["m01"] / M["m00"]
        d = float(np.hypot(fx - x_c, fy - y_c))
        # a maior mancha azul perto da bolinha verde
        if min_dist_px <= d <= max_dist_px and M["m00"] > best_area:
            best = (fx, fy)
            best_area = M["m00"]

    return best


#Extracts the car contour (green marker at the car centre)
#Parameters: Frame with the car in view, draw_flag -> 0 if visual representation not needed. draw_flag -> 1 otherwise
#Returns: Car's contour and (if draw_flag = 1) the same frame with the contour drawn on
def carcontour(frame, draw_flag=0):

    if frame is None:
        return None if not draw_flag else (None,None)

    #Find contours
    contours = color_contours(frame, LOWER_GREEN, UPPER_GREEN)
    if not contours:
        return None if not draw_flag else (None,None)

    #Get largest contour
    largest = max(contours, key=cv2.contourArea)

    #Draw on image
    if draw_flag:
        img = frame.copy()
        cv2.drawContours(img, [largest], -1, (0, 252, 124), 2)
        return largest, img

    return largest

#Compute the cars' center
#Parameters: Car's contour, track's contour, draw_flag and current frame
#Returns: Car's centre (x, y) and (if draw_flag -> 1) the frame with center drawn
#Updates lap time and lap number, and gives window a slight red tint if car out of bounds
def carcentre(car_contour, track_contour, draw_flag=0, img=None, src_frame=None):

    global FINISHING_LINE_MIN_X, FINISHING_LINE_MAX_X, FINISHING_LINE_MIN_Y, FINISHING_LINE_MAX_Y, red, lap_number, lap_start_time, lap_time, batota, f_red, aux, front_marker_ok

    if car_contour is None or track_contour is None:
        return (-1, -1, img) if draw_flag else (-1, -1)

    # Calculate moments and validate
    M = cv2.moments(car_contour)
    if M["m00"] == 0:
        return (-1, -1, img) if draw_flag else (-1, -1)

    #Get centre coordinates (green marker)
    x_f = M["m10"] / M["m00"]
    y_f = M["m01"] / M["m00"]
    x = int(x_f)
    y = int(y_f)
    x_m, y_m = px_to_m(x, y)

    #Heading from the green (centre) to the blue (front) marker, sub-pixel
    #(src_frame: frame limpo, sem os desenhos a azul do caminho)
    front_px = front_marker(src_frame, x_f, y_f)
    front_m = None
    if front_px is not None:
        front_m = px_to_m(*front_px)
    front_marker_ok = front_m is not None
    theta_rad = update_raw_theta(*px_to_m(x_f, y_f), time.time(), front_m)
    theta_deg = float(np.degrees(theta_rad))

    #Check to see if centre in limits or out
    InorOut = cv2.pointPolygonTest(track_contour, (x,y), False)

    if not draw_flag:
        return x, y
    
    if img is None:
        return -1, -1, None  


    if draw_flag:

        #On track
        if InorOut == 1:

            #If it just left the finishing line
            if aux == 1:
                lap_start_time = time.time()

            aux = 0
            cv2.circle(img, (x,y), radius = 2, color=[0, 255, 0],
                    thickness=5)
            
            f_red = 0

            return x, y, img

        #Crossing the finishing line
        elif FINISHING_LINE_MIN_X <= x <= FINISHING_LINE_MAX_X and FINISHING_LINE_MIN_Y <= y <= FINISHING_LINE_MAX_Y:

            #First time crossing it
            if aux == 0:

                lap_time = time.time() - lap_start_time

                #If it went out of bounds
                if batota != 0:
                    lap_time = round(lap_time + 3 * batota, 2)
                else:
                    lap_time = round(lap_time, 2)
                batota = 0
                lap_number += 1
                aux = 1
            
            cv2.circle(img, (x, y), 2, (0, 255, 255), 5)
            return x, y, img
            
        #Out of Bounds
        else:

            #if it wasnt already out of bounds
            if f_red == 0:
                batota += 1
                f_red = 1
            
            if red is not None:
                cv2.addWeighted(img, alpha, red, beta, 0.0, img)

            return x, y, img

#View specific frames
#Parameters: name of window and frame to be displayed
def show(name, frame, recorder=None):

    cv2.imshow(name, frame)
    if recorder is not None:
        recorder.write(frame)
    return cv2.waitKey(1) & 0xFF

#check if the function worked
def check(cap):

    print("Camera error.")
    cap.release()
    cv2.destroyAllWindows()
    exit()

#Load the calibration parameters
if os.path.exists("calibration_data.npz"):
    with np.load("calibration_data.npz") as data:
        mtx = data['camera_matrix']
        dist = data['dist_coeff']
else:
    print("Calibration file not found.")
    exit()

def main():

    global click_count, FINISHING_LINE_MIN_X, FINISHING_LINE_MAX_X, FINISHING_LINE_MIN_Y, FINISHING_LINE_MAX_Y, contour, lap_number, lap_time, best_lap_time

    #Open the camera
    cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_MSMF)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    live_recorder = None
    tracking_recorder = None
    frame_counter = 0
    ret, frame = cap.read()
    if not ret:
        check(cap)    

    if SELECT_CROP_AT_START:
        select_crop(cap)

    calibrate_marker_colors(cap)

    #Get Track Limits
    while True:

        ret, frame = cap.read()
        if not ret:
            check(cap)
         
        #Process frame
        frame = process_frame(frame)

        #Get the tracks limits
        img, contour = limits(frame)
        cv2.imshow("limits", img)
            
        key = cv2.waitKey(0) & 0xFF
        if key in [ord('c'), ord('C')]:
            break

        if key in [ord('q'), ord('Q')]:
            cv2.destroyAllWindows()
            cap.release()
            exit()
        
    cv2.destroyAllWindows()

    #Get finishing line coordinates
    cv2.namedWindow("Live")
    cv2.setMouseCallback("Live", set_finishing_line)

    print("Select the upper left corner of the finishing line")

    #Loop until all coordinatess are set
    while click_count < 2:

        ret, frame = cap.read()
        if not ret:
            check(cap)
        
        frame = process_frame(frame)
        if frame is None:
            continue

        cv2.imshow("Live", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()

    #Load red image for overlay
    overlay(frame.shape)
    if red is None:
        print("Warning: Red overlay not loaded. Skipping overlay functionality.")

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    recording_fps = get_recording_fps(cap)
    live_recorder = WindowRecorder("Live", "live", recording_fps, timestamp)
    tracking_recorder = WindowRecorder("Tracking", "tracking", recording_fps, timestamp)
    run_log = None
    if RECORD_LOG:
        run_log = VideoRunLog(timestamp, recording_fps,
                              [live_recorder.path, tracking_recorder.path])
        atexit.register(run_log.close)  # fecha o log mesmo com Ctrl+C ou erro da camera
    atexit.register(live_recorder.release)
    atexit.register(tracking_recorder.release)

    cv2.namedWindow("Tracking")
    cv2.setMouseCallback("Tracking", edit_control_points)
    print("Editor: arrasta os pontos do caminho/barreiras ou os obstaculos na janela Tracking e carrega em S para guardar.")
    print("Tracking: carrega em Enter para guardar o frame atual em PDF.")
    print("Tracking: o desvio do angulo das bolinhas e estimado em andamento; O guarda-o no shared_config.")
    last_tracking_frame = None

    #Tracking the car
    while True:
        t_loop = time.perf_counter()

        ret, frame = cap.read()
        t_capture = time.time()
        t_capture_done = time.perf_counter()
        if not ret:
            check(cap)
        frame_counter += 1

        #Process each frame
        t_process_start = time.perf_counter()
        frame = process_frame(frame)
        t_process_done = time.perf_counter()

        #Get car contour (antes de mostrar as janelas: o UDP sai o mais cedo possivel)
        t_tracking_start = time.perf_counter()
        car_contour = carcontour(frame)

        display_frame = frame.copy()
        draw_static_overlay(display_frame)

        img = None
        if car_contour is not None:
            #Get car center
            x, y, img = carcentre(car_contour, contour, draw_flag=1, img=display_frame, src_frame=frame)
        t_tracking_done = time.perf_counter()

        if img is not None:
            x_m, y_m = px_to_m(x, y)
            if SEND_UDP and np.isfinite(x_m) and np.isfinite(y_m):
                timing_ms = {
                    "image_acquisition": (t_capture_done - t_loop) * 1000.0,
                    "image_processing": (
                        (t_process_done - t_process_start)
                        + (t_tracking_done - t_tracking_start)
                    ) * 1000.0,
                    "image_preprocess": (t_process_done - t_process_start) * 1000.0,
                    "tracking_processing": (t_tracking_done - t_tracking_start) * 1000.0,
                    "vision_loop": (t_tracking_done - t_loop) * 1000.0,
                }
                payload = build_udp_payload(frame_counter, x, y, x_m, y_m,
                                            timing_ms=timing_ms, t_capture=t_capture)
                sock.sendto(json.dumps(payload).encode("utf-8"), (PC_IP, PC_PORT))

        #Log da pose (1 linha por frame gravado nos videos)
        if run_log is not None:
            if img is not None and x >= 0:
                run_log.log(frame_counter, t_capture, True, x_m, y_m, x, y)
            else:
                run_log.log(frame_counter, t_capture, False)

        #Display (so depois de enviar o estado)
        cv2.imshow("Live", frame)
        live_recorder.write(frame)

        if img is None:
            last_tracking_frame = display_frame
            key = show("Tracking", display_frame, tracking_recorder)
            if handle_tracking_key(key, last_tracking_frame):
                break
            continue

        #Update best lap time
        if lap_time < best_lap_time:
            best_lap_time = lap_time

        #Update lap info
        phrases = [
            f"LAP: {lap_number}",
            f"TIME:{lap_time:.2f}s",
            f"BEST:{best_lap_time:.2f}s"
        ]

        last_tracking_frame = img.copy()

        #Display border and lap info
        if SHOW_LAP_INFO:
            img = apply_border(img, phrases)
        key = show("Tracking", img, tracking_recorder)
        if handle_tracking_key(key, last_tracking_frame):
            break

    if live_recorder is not None:
        live_recorder.release()
    if tracking_recorder is not None:
        tracking_recorder.release()
    if run_log is not None:
        run_log.close()
    cap.release()
    sock.close()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
